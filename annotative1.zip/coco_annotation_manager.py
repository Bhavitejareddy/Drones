#!/usr/bin/env python3
"""
COCO Annotation Manager
========================
Safely maintain a large COCO-style annotations.json (60k+ images) when:

  a) A single image's annotations change (ship added/removed etc.) and you
     have a small "patch" JSON for just that one image (matching file_name
     with the master file).
  b) An image is deleted entirely -> its entry AND all its annotations must
     be removed from the master file.

Every write is backed up first and logged to change_log.jsonl so you have a
full audit trail across 60k images.

-------------------------------------------------------------------------
USAGE
-------------------------------------------------------------------------
1) Merge a single-image patch into the master annotations file
   (patch.json can look exactly like your example, just for ONE image):

   python coco_annotation_manager.py update \
       --master annotations.json \
       --patch  image001_patch.json

2) Delete an image + its annotations from the master file:

   python coco_annotation_manager.py delete \
       --master annotations.json \
       --file-name image001.jpg

3) (Optional, not recommended for 60k images) Compact/renumber all ids so
   they are contiguous again:

   python coco_annotation_manager.py compact --master annotations.json

4) Sanity-check the file (orphan annotations, duplicate ids/file_names):

   python coco_annotation_manager.py validate --master annotations.json
-------------------------------------------------------------------------
"""

import argparse
import json
import shutil
import sys
from datetime import datetime
from pathlib import Path

LOG_FILE = "change_log.jsonl"


# --------------------------------------------------------------------------
# Core I/O helpers
# --------------------------------------------------------------------------

def load_coco(path: Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_coco(coco: dict, path: Path) -> None:
    # sort_keys + indent -> stable, git-diff-friendly output
    with open(path, "w", encoding="utf-8") as f:
        json.dump(coco, f, indent=2, sort_keys=False)


def backup_file(path: Path) -> Path:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = path.with_name(f"{path.stem}.bak_{ts}{path.suffix}")
    shutil.copy2(path, backup_path)
    return backup_path


def log_change(action: str, details: dict, log_path: Path) -> None:
    entry = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "action": action,
        **details,
    }
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")


def next_id(items: list, key: str = "id") -> int:
    if not items:
        return 1
    return max(item[key] for item in items) + 1


def index_images_by_file_name(coco: dict) -> dict:
    return {img["file_name"]: img for img in coco["images"]}


# --------------------------------------------------------------------------
# a) Update / merge a single image's annotations from a patch file
# --------------------------------------------------------------------------

def update_image_annotations(master: dict, patch: dict, log_path: Path) -> dict:
    """
    patch is expected to have the same shape as the master file but scoped
    to ONE image, e.g.:
    {
      "images": [{"id": 1, "file_name": "image001.jpg", "width":..., "height":...}],
      "annotations": [ {...}, {...} ]   # the FULL new set of annotations for this image
    }

    Behaviour:
      - Find the real image entry in master by file_name (id in the patch is
        ignored/local-only; only file_name is used to match).
      - Update that image's width/height if they differ (in case they were
        wrong or the image was resized).
      - Remove all EXISTING annotations in master belonging to that image_id.
      - Insert the patch's annotations, assigning them fresh unique ids and
        pointing image_id at the real master image id.
    """
    if not patch.get("images"):
        raise ValueError("Patch file must contain an 'images' entry for the target image.")

    # Category ids inside the patch are LOCAL to the patch (e.g. MiniLabel
    # assigns its own ids, possibly including a brand-new category created on
    # the fly). We always remap by category NAME, never trust the patch's raw
    # category_id directly, so this works whether or not the patch's ids
    # happen to line up with master's.
    category_id_map = {}  # patch local category id -> real master category id
    if patch.get("categories"):
        master.setdefault("categories", [])
        name_to_master_id = {c["name"]: c["id"] for c in master["categories"]}
        next_cat_id = next_id(master["categories"])
        for cat in patch["categories"]:
            if cat["name"] not in name_to_master_id:
                master["categories"].append({"id": next_cat_id, "name": cat["name"]})
                name_to_master_id[cat["name"]] = next_cat_id
                next_cat_id += 1
            category_id_map[cat["id"]] = name_to_master_id[cat["name"]]

    patch_image = patch["images"][0]
    file_name = patch_image["file_name"]

    images_by_name = index_images_by_file_name(master)
    if file_name not in images_by_name:
        raise ValueError(
            f"'{file_name}' not found in master file. "
            f"If this is a NEW image, add it via a separate 'add-image' step "
            f"instead of 'update'."
        )

    master_image = images_by_name[file_name]
    real_image_id = master_image["id"]

    # Sync width/height if provided and different
    for field in ("width", "height"):
        if field in patch_image and patch_image[field] != master_image.get(field):
            master_image[field] = patch_image[field]

    # Remove old annotations for this image
    before_count = sum(1 for a in master["annotations"] if a["image_id"] == real_image_id)
    master["annotations"] = [
        a for a in master["annotations"] if a["image_id"] != real_image_id
    ]

    # Insert new annotations with fresh global ids
    new_ann_ids = []
    ann_id = next_id(master["annotations"])
    for ann in patch.get("annotations", []):
        new_ann = dict(ann)  # copy, don't mutate patch
        new_ann["id"] = ann_id
        new_ann["image_id"] = real_image_id
        if category_id_map:
            new_ann["category_id"] = category_id_map.get(ann["category_id"], ann["category_id"])
        master["annotations"].append(new_ann)
        new_ann_ids.append(ann_id)
        ann_id += 1

    log_change(
        "update_image_annotations",
        {
            "file_name": file_name,
            "image_id": real_image_id,
            "removed_annotation_count": before_count,
            "added_annotation_ids": new_ann_ids,
        },
        log_path,
    )
    return master


# --------------------------------------------------------------------------
# b) Delete an image and all its annotations
# --------------------------------------------------------------------------

def delete_image(master: dict, file_name: str, log_path: Path) -> dict:
    images_by_name = index_images_by_file_name(master)
    if file_name not in images_by_name:
        raise ValueError(f"'{file_name}' not found in master file.")

    image_id = images_by_name[file_name]["id"]

    master["images"] = [img for img in master["images"] if img["file_name"] != file_name]

    before_count = len(master["annotations"])
    master["annotations"] = [a for a in master["annotations"] if a["image_id"] != image_id]
    removed_ann_count = before_count - len(master["annotations"])

    log_change(
        "delete_image",
        {
            "file_name": file_name,
            "deleted_image_id": image_id,
            "removed_annotation_count": removed_ann_count,
        },
        log_path,
    )
    return master


# --------------------------------------------------------------------------
# Batch helpers: apply everything MiniLabel produced in one go
# --------------------------------------------------------------------------

def batch_update_from_folder(master: dict, patches_dir: Path, log_path: Path) -> dict:
    """Apply every *_patch.json file in a folder (e.g. MiniLabel's output) in
    one pass, so a single backup covers the whole batch instead of one per
    image."""
    patch_files = sorted(patches_dir.glob("*.json"))
    if not patch_files:
        print(f"No patch files found in {patches_dir}")
        return master
    for pf in patch_files:
        patch = load_coco(pf)
        try:
            master = update_image_annotations(master, patch, log_path)
            print(f"  applied: {pf.name}")
        except ValueError as e:
            print(f"  SKIPPED {pf.name}: {e}")
    return master


def apply_deletion_queue(master: dict, queue_path: Path, log_path: Path) -> dict:
    """queue_path is a JSON file: {"delete": ["image001.jpg", "image045.jpg", ...]}
    Produced by MiniLabel's 'Delete Image' action. Applies every deletion in
    one pass under a single backup."""
    with open(queue_path, "r", encoding="utf-8") as f:
        queue = json.load(f)
    for file_name in queue.get("delete", []):
        try:
            master = delete_image(master, file_name, log_path)
            print(f"  deleted: {file_name}")
        except ValueError as e:
            print(f"  SKIPPED {file_name}: {e}")
    return master


# --------------------------------------------------------------------------
# Optional: compact/renumber ids to be contiguous again (1..N)
# NOTE: not recommended for a 60k-image dataset unless you have a specific
# reason (e.g. an external tool requires contiguous ids). Gaps in ids are
# perfectly valid COCO.
# --------------------------------------------------------------------------

def compact_ids(master: dict, log_path: Path) -> dict:
    old_to_new_img = {}
    for new_id, img in enumerate(
        sorted(master["images"], key=lambda x: x["id"]), start=1
    ):
        old_to_new_img[img["id"]] = new_id
        img["id"] = new_id

    old_to_new_ann = {}
    for new_id, ann in enumerate(
        sorted(master["annotations"], key=lambda x: x["id"]), start=1
    ):
        old_to_new_ann[ann["id"]] = new_id
        ann["id"] = new_id
        ann["image_id"] = old_to_new_img[ann["image_id"]]

    log_change(
        "compact_ids",
        {
            "image_count": len(old_to_new_img),
            "annotation_count": len(old_to_new_ann),
        },
        log_path,
    )
    return master


# --------------------------------------------------------------------------
# Validation / sanity checks
# --------------------------------------------------------------------------

def validate(master: dict) -> list:
    problems = []

    image_ids = [img["id"] for img in master["images"]]
    if len(image_ids) != len(set(image_ids)):
        problems.append("Duplicate image ids found.")

    file_names = [img["file_name"] for img in master["images"]]
    if len(file_names) != len(set(file_names)):
        problems.append("Duplicate file_names found.")

    ann_ids = [a["id"] for a in master["annotations"]]
    if len(ann_ids) != len(set(ann_ids)):
        problems.append("Duplicate annotation ids found.")

    valid_image_ids = set(image_ids)
    orphans = [a["id"] for a in master["annotations"] if a["image_id"] not in valid_image_ids]
    if orphans:
        problems.append(f"{len(orphans)} annotation(s) reference a missing image_id: {orphans[:20]}...")

    valid_cat_ids = {c["id"] for c in master.get("categories", [])}
    bad_cats = [a["id"] for a in master["annotations"] if a["category_id"] not in valid_cat_ids]
    if bad_cats:
        problems.append(f"{len(bad_cats)} annotation(s) reference an unknown category_id: {bad_cats[:20]}...")

    return problems


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="COCO annotation maintenance tool")
    parser.add_argument("--master", required=True, help="Path to the master annotations.json")
    parser.add_argument("--no-backup", action="store_true", help="Skip creating a backup before writing")
    sub = parser.add_subparsers(dest="command", required=True)

    p_update = sub.add_parser("update", help="Merge a single-image patch into the master file")
    p_update.add_argument("--patch", required=True, help="Path to the single-image patch JSON")

    p_delete = sub.add_parser("delete", help="Delete an image + its annotations")
    p_delete.add_argument("--file-name", required=True, help="file_name of the image to delete")

    p_batch = sub.add_parser("batch-update", help="Apply every patch *.json in a folder (e.g. from MiniLabel)")
    p_batch.add_argument("--patches-dir", required=True, help="Folder containing per-image patch JSON files")

    p_apply_del = sub.add_parser("apply-deletions", help="Apply a MiniLabel delete-queue JSON")
    p_apply_del.add_argument("--queue", required=True, help="Path to delete_queue.json")

    sub.add_parser("compact", help="Renumber image/annotation ids to be contiguous (1..N)")
    sub.add_parser("validate", help="Check the master file for integrity problems")

    args = parser.parse_args()
    master_path = Path(args.master)
    log_path = master_path.parent / LOG_FILE

    master = load_coco(master_path)

    if args.command == "validate":
        problems = validate(master)
        if problems:
            print("Found problems:")
            for p in problems:
                print(f"  - {p}")
            sys.exit(1)
        else:
            print("No problems found.")
        return

    if not args.no_backup:
        backup_path = backup_file(master_path)
        print(f"Backup written to: {backup_path}")

    if args.command == "update":
        patch = load_coco(Path(args.patch))
        master = update_image_annotations(master, patch, log_path)
        print(f"Updated annotations for '{patch['images'][0]['file_name']}'.")

    elif args.command == "delete":
        master = delete_image(master, args.file_name, log_path)
        print(f"Deleted '{args.file_name}' and its annotations.")

    elif args.command == "batch-update":
        master = batch_update_from_folder(master, Path(args.patches_dir), log_path)

    elif args.command == "apply-deletions":
        master = apply_deletion_queue(master, Path(args.queue), log_path)

    elif args.command == "compact":
        master = compact_ids(master, log_path)
        print("Compacted image/annotation ids.")

    save_coco(master, master_path)
    print(f"Saved: {master_path}")
    print(f"Change logged to: {log_path}")


if __name__ == "__main__":
    main()
