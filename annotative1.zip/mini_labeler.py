#!/usr/bin/env python3
"""
MiniLabel — a tiny offline LabelImg/LabelMe-style tool for editing an
existing COCO dataset (add/remove bounding boxes, mark images for deletion)
WITHOUT ever writing directly to the master annotations.json.

Instead, every edit is exported as a small file that coco_annotation_manager.py
already knows how to apply:

  - Editing an image's boxes  -> patches/<file_name>_patch.json
       (apply later with: coco_annotation_manager.py update --patch ...
        or in bulk with:  coco_annotation_manager.py batch-update --patches-dir patches/)

  - Marking an image deleted  -> delete_queue.json  {"delete": ["image017.jpg", ...]}
       (apply later with: coco_annotation_manager.py apply-deletions --queue delete_queue.json)

Nothing here ever overwrites annotations.json directly — that keeps the same
backup + audit-log guarantees from coco_annotation_manager.py intact, and lets
you review every patch file before it's merged into the master.

Dependencies: tkinter (stdlib) + Pillow (`pip install Pillow`).

Usage:
    python3 mini_labeler.py --master annotations.json --images images/ --out patches/

Controls:
    - Left-click + drag on the image  : draw a new box
    - Click a row in the box list      : select a box (highlights it)
    - Delete key / "Delete box" button : remove the selected box
    - "Save patch for this image"      : writes patches/<file_name>_patch.json
    - "Mark image for deletion"        : queues the CURRENT image for deletion
                                          (its patch, if any, is skipped)
    - Prev / Next                      : move through the image list
                                          (auto-saves nothing — you must click
                                          "Save patch" explicitly per image)
"""

import argparse
import json
import sys
from pathlib import Path

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

from PIL import Image, ImageTk

CANVAS_MAX_W = 900
CANVAS_MAX_H = 650

PALETTE = [
    "#e6194b", "#3cb44b", "#ffe119", "#4363d8", "#f58231",
    "#911eb4", "#46f0f0", "#f032e6", "#bcf60c", "#fabebe",
]


def color_for(category_id: int) -> str:
    return PALETTE[category_id % len(PALETTE)]


# ----------------------------------------------------------------------------
# Pure helper functions (no Tk/display dependency) — unit-testable in isolation
# ----------------------------------------------------------------------------

def canvas_to_image_bbox(x0, y0, x1, y1, scale):
    """Convert a drag rectangle in on-screen canvas pixels into an
    (x, y, w, h) bbox in ORIGINAL image pixel coordinates."""
    left, right = sorted((x0, x1))
    top, bottom = sorted((y0, y1))
    ox, oy = left / scale, top / scale
    ow, oh = (right - left) / scale, (bottom - top) / scale
    return [ox, oy, ow, oh]


def image_bbox_to_canvas_rect(bbox, scale):
    """Convert an original-image-pixel bbox [x,y,w,h] into on-screen
    canvas rectangle coords (x0, y0, x1, y1) for drawing."""
    x, y, w, h = bbox
    return x * scale, y * scale, (x + w) * scale, (y + h) * scale


def build_patch(file_name, width, height, categories: dict, boxes: list) -> dict:
    """Build the per-image patch dict in the exact shape
    coco_annotation_manager.py's `update` command expects.

    categories: {category_id: name} covering every category referenced by `boxes`
    boxes: list of {"category_id": int, "bbox": [x, y, w, h]}
    """
    return {
        "images": [{
            "id": 1,
            "file_name": file_name,
            "width": width,
            "height": height,
        }],
        "categories": [{"id": cid, "name": name} for cid, name in categories.items()],
        "annotations": [
            {
                "category_id": b["category_id"],
                "bbox": [round(v, 2) for v in b["bbox"]],
                "area": round(b["bbox"][2] * b["bbox"][3], 2),
                "iscrowd": 0,
            }
            for b in boxes
        ],
    }


class MiniLabel(tk.Tk):
    def __init__(self, master_path: Path, images_dir: Path, out_dir: Path):
        super().__init__()
        self.title("MiniLabel — COCO patch editor")
        self.geometry("1200x760")

        self.master_path = master_path
        self.images_dir = images_dir
        self.out_dir = out_dir
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.delete_queue_path = self.master_path.parent / "delete_queue.json"

        with open(master_path, "r", encoding="utf-8") as f:
            self.coco = json.load(f)

        self.categories = {c["id"]: c["name"] for c in self.coco.get("categories", [])}
        self.name_to_cat_id = {v: k for k, v in self.categories.items()}
        self.next_local_cat_id = (max(self.categories.keys()) + 1) if self.categories else 1

        self.images = sorted(self.coco["images"], key=lambda x: x["file_name"])
        self.ann_by_image_id = {}
        for a in self.coco["annotations"]:
            self.ann_by_image_id.setdefault(a["image_id"], []).append(a)

        self.pending_deletions = self._load_delete_queue()
        self.saved_patches = self._scan_saved_patches()

        self.current_index = 0
        self.working_boxes = []  # list of dicts: {category_id, bbox=[x,y,w,h]}
        self.scale = 1.0
        self.tk_img = None
        self.drag_start = None
        self.drag_rect_id = None

        self._build_ui()
        self._load_current_image()

    # ------------------------------------------------------------------
    # Setup helpers
    # ------------------------------------------------------------------

    def _scan_saved_patches(self):
        names = set()
        for p in self.out_dir.glob("*_patch.json"):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    data = json.load(f)
                names.add(data["images"][0]["file_name"])
            except Exception:
                pass
        return names

    def _load_delete_queue(self):
        if self.delete_queue_path.exists():
            with open(self.delete_queue_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return set(data.get("delete", []))
        return set()

    def _save_delete_queue(self):
        with open(self.delete_queue_path, "w", encoding="utf-8") as f:
            json.dump({"delete": sorted(self.pending_deletions)}, f, indent=2)

    # ------------------------------------------------------------------
    # UI layout
    # ------------------------------------------------------------------

    def _build_ui(self):
        root = ttk.Frame(self)
        root.pack(fill="both", expand=True)

        # Left: image list
        left = ttk.Frame(root, width=260)
        left.pack(side="left", fill="y")
        ttk.Label(left, text="Images", font=("", 11, "bold")).pack(anchor="w", padx=6, pady=(6, 0))
        self.image_listbox = tk.Listbox(left, width=34)
        self.image_listbox.pack(fill="y", expand=True, padx=6, pady=6)
        for img in self.images:
            self.image_listbox.insert("end", self._label_for(img["file_name"]))
        self.image_listbox.bind("<<ListboxSelect>>", self._on_select_image)

        # Center: canvas
        center = ttk.Frame(root)
        center.pack(side="left", fill="both", expand=True)
        self.canvas = tk.Canvas(center, bg="#222222", width=CANVAS_MAX_W, height=CANVAS_MAX_H)
        self.canvas.pack(padx=8, pady=8)
        self.canvas.bind("<ButtonPress-1>", self._on_press)
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_release)

        nav = ttk.Frame(center)
        nav.pack(fill="x", padx=8)
        ttk.Button(nav, text="<< Prev", command=self._prev_image).pack(side="left")
        ttk.Button(nav, text="Next >>", command=self._next_image).pack(side="left", padx=6)
        self.status_var = tk.StringVar()
        ttk.Label(nav, textvariable=self.status_var).pack(side="left", padx=12)

        # Right: box list + actions
        right = ttk.Frame(root, width=280)
        right.pack(side="right", fill="y")
        ttk.Label(right, text="Boxes on this image", font=("", 11, "bold")).pack(anchor="w", padx=6, pady=(6, 0))
        self.box_listbox = tk.Listbox(right, width=36, height=18)
        self.box_listbox.pack(padx=6, pady=6)
        self.box_listbox.bind("<<ListboxSelect>>", self._on_select_box)
        self.bind("<Delete>", lambda e: self._delete_selected_box())

        ttk.Button(right, text="Delete selected box", command=self._delete_selected_box).pack(fill="x", padx=6, pady=2)
        ttk.Separator(right).pack(fill="x", padx=6, pady=8)
        ttk.Button(right, text="Save patch for this image", command=self._save_patch).pack(fill="x", padx=6, pady=2)
        self.delete_btn = ttk.Button(right, text="Mark image for deletion", command=self._toggle_delete_current)
        self.delete_btn.pack(fill="x", padx=6, pady=2)
        ttk.Separator(right).pack(fill="x", padx=6, pady=8)
        ttk.Label(right, text=f"Patches saved to:\n{self.out_dir}", wraplength=250, foreground="#555").pack(padx=6, pady=(0, 4), anchor="w")
        ttk.Label(right, text=f"Delete queue:\n{self.delete_queue_path}", wraplength=250, foreground="#555").pack(padx=6, pady=(0, 4), anchor="w")
        ttk.Label(
            right,
            text="Nothing here writes to the master file.\nRun coco_annotation_manager.py\nbatch-update / apply-deletions\nwhen you're ready to merge.",
            wraplength=250, foreground="#a33",
        ).pack(padx=6, pady=10, anchor="w")

    def _label_for(self, file_name: str) -> str:
        tag = ""
        if file_name in self.pending_deletions:
            tag = "  [DELETE]"
        elif file_name in getattr(self, "saved_patches", set()):
            tag = "  [patched]"
        return file_name + tag

    def _refresh_listbox_label(self, idx: int):
        img = self.images[idx]
        self.image_listbox.delete(idx)
        self.image_listbox.insert(idx, self._label_for(img["file_name"]))

    # ------------------------------------------------------------------
    # Image loading / navigation
    # ------------------------------------------------------------------

    def _on_select_image(self, event):
        sel = self.image_listbox.curselection()
        if sel:
            self.current_index = sel[0]
            self._load_current_image()

    def _prev_image(self):
        if self.current_index > 0:
            self.current_index -= 1
            self.image_listbox.selection_clear(0, "end")
            self.image_listbox.selection_set(self.current_index)
            self._load_current_image()

    def _next_image(self):
        if self.current_index < len(self.images) - 1:
            self.current_index += 1
            self.image_listbox.selection_clear(0, "end")
            self.image_listbox.selection_set(self.current_index)
            self._load_current_image()

    def _load_current_image(self):
        img_meta = self.images[self.current_index]
        file_name = img_meta["file_name"]
        path = self.images_dir / file_name
        self.canvas.delete("all")

        if not path.exists():
            self.status_var.set(f"MISSING FILE: {file_name}")
            self.pil_img = None
            self.working_boxes = []
            self._refresh_box_listbox()
            return

        pil_img = Image.open(path).convert("RGB")
        w, h = pil_img.size
        self.scale = min(CANVAS_MAX_W / w, CANVAS_MAX_H / h, 1.0)
        disp_w, disp_h = int(w * self.scale), int(h * self.scale)
        disp_img = pil_img.resize((disp_w, disp_h)) if self.scale != 1.0 else pil_img
        self.tk_img = ImageTk.PhotoImage(disp_img)
        self.canvas.config(width=disp_w, height=disp_h)
        self.canvas.create_image(0, 0, anchor="nw", image=self.tk_img)

        # Working boxes start from master annotations, in bbox=[x,y,w,h] form
        existing = self.ann_by_image_id.get(img_meta["id"], [])
        self.working_boxes = [
            {"category_id": a["category_id"], "bbox": list(a["bbox"])} for a in existing
        ]

        deleted = file_name in self.pending_deletions
        self.status_var.set(
            f"{self.current_index + 1}/{len(self.images)} — {file_name}"
            + ("  [MARKED FOR DELETION]" if deleted else "")
        )
        self.delete_btn.config(text="Unmark deletion" if deleted else "Mark image for deletion")

        self._redraw_boxes()
        self._refresh_box_listbox()

    # ------------------------------------------------------------------
    # Drawing / editing boxes
    # ------------------------------------------------------------------

    def _redraw_boxes(self, highlight_idx=None):
        self.canvas.delete("box")
        for i, b in enumerate(self.working_boxes):
            x0, y0, x1, y1 = image_bbox_to_canvas_rect(b["bbox"], self.scale)
            color = color_for(b["category_id"])
            width = 3 if i == highlight_idx else 2
            self.canvas.create_rectangle(x0, y0, x1, y1, outline=color, width=width, tags="box")
            name = self.categories.get(b["category_id"], f"id{b['category_id']}")
            self.canvas.create_text(x0 + 3, y0 - 8, anchor="nw", text=name, fill=color, tags="box")

    def _refresh_box_listbox(self):
        self.box_listbox.delete(0, "end")
        for b in self.working_boxes:
            name = self.categories.get(b["category_id"], f"id{b['category_id']}")
            x, y, w, h = [round(v) for v in b["bbox"]]
            self.box_listbox.insert("end", f"{name}  [{x},{y},{w},{h}]")

    def _on_press(self, event):
        if getattr(self, "pil_img", "unset") is None:
            return
        self.drag_start = (event.x, event.y)
        self.drag_rect_id = self.canvas.create_rectangle(
            event.x, event.y, event.x, event.y, outline="#ffffff", width=2, dash=(4, 2)
        )

    def _on_drag(self, event):
        if self.drag_rect_id is None or self.drag_start is None:
            return
        x0, y0 = self.drag_start
        self.canvas.coords(self.drag_rect_id, x0, y0, event.x, event.y)

    def _on_release(self, event):
        if self.drag_rect_id is None or self.drag_start is None:
            return
        x0, y0 = self.drag_start
        x1, y1 = event.x, event.y
        self.canvas.delete(self.drag_rect_id)
        self.drag_rect_id = None
        self.drag_start = None

        if abs(x1 - x0) < 4 or abs(y1 - y0) < 4:
            return  # accidental click, not a real box

        bbox = canvas_to_image_bbox(x0, y0, x1, y1, self.scale)

        cat_id = self._ask_category()
        if cat_id is None:
            return

        self.working_boxes.append({"category_id": cat_id, "bbox": bbox})
        self._redraw_boxes()
        self._refresh_box_listbox()

    def _ask_category(self):
        """Small picker: type an existing category name or a brand-new one."""
        names = sorted(self.name_to_cat_id.keys())
        prompt = "Category name" + (f"\n(existing: {', '.join(names)})" if names else "")
        name = simpledialog.askstring("Category", prompt, parent=self)
        if not name:
            return None
        name = name.strip()
        if name in self.name_to_cat_id:
            return self.name_to_cat_id[name]
        # brand-new category: assign a local id; manager.py maps by NAME on merge
        new_id = self.next_local_cat_id
        self.next_local_cat_id += 1
        self.name_to_cat_id[name] = new_id
        self.categories[new_id] = name
        return new_id

    def _on_select_box(self, event):
        sel = self.box_listbox.curselection()
        if sel:
            self._redraw_boxes(highlight_idx=sel[0])

    def _delete_selected_box(self):
        sel = self.box_listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        del self.working_boxes[idx]
        self._redraw_boxes()
        self._refresh_box_listbox()

    # ------------------------------------------------------------------
    # Export: patch file for current image
    # ------------------------------------------------------------------

    def _save_patch(self):
        img_meta = self.images[self.current_index]
        file_name = img_meta["file_name"]

        if file_name in self.pending_deletions:
            messagebox.showwarning(
                "Image marked for deletion",
                f"'{file_name}' is marked for deletion — unmark it first if you want to save box edits.",
            )
            return

        patch = build_patch(
            file_name, img_meta.get("width"), img_meta.get("height"),
            self.categories, self.working_boxes,
        )

        out_path = self.out_dir / f"{Path(file_name).stem}_patch.json"
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(patch, f, indent=2)

        self.saved_patches.add(file_name)
        self._refresh_listbox_label(self.current_index)
        messagebox.showinfo("Saved", f"Patch written:\n{out_path}\n\n{len(patch['annotations'])} box(es).")

    # ------------------------------------------------------------------
    # Deletion queue
    # ------------------------------------------------------------------

    def _toggle_delete_current(self):
        img_meta = self.images[self.current_index]
        file_name = img_meta["file_name"]
        if file_name in self.pending_deletions:
            self.pending_deletions.remove(file_name)
        else:
            if not messagebox.askyesno(
                "Confirm",
                f"Mark '{file_name}' for deletion?\n\nThis only queues it — the master file "
                f"is untouched until you run:\n  coco_annotation_manager.py apply-deletions",
            ):
                return
            self.pending_deletions.add(file_name)
        self._save_delete_queue()
        self._refresh_listbox_label(self.current_index)
        self._load_current_image()


def main():
    parser = argparse.ArgumentParser(description="MiniLabel — offline COCO patch editor")
    parser.add_argument("--master", required=True, help="Path to master annotations.json (read-only here)")
    parser.add_argument("--images", required=True, help="Path to the folder of images")
    parser.add_argument("--out", default="patches", help="Folder to write per-image patch JSON files into")
    args = parser.parse_args()

    master_path = Path(args.master)
    images_dir = Path(args.images)
    out_dir = Path(args.out)

    if not master_path.exists():
        sys.exit(f"Master file not found: {master_path}")
    if not images_dir.exists():
        sys.exit(f"Images folder not found: {images_dir}")

    app = MiniLabel(master_path, images_dir, out_dir)
    app.mainloop()


if __name__ == "__main__":
    main()
