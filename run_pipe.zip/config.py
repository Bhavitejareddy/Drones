"""
DRONE CLASSIFICATION PIPELINE — SHARED CONFIG
===================================================
Fill in the paths below. Every step script (step1_crop.py ... step5_infer.py)
imports its settings from this file, so you only need to edit paths in ONE place.

Run steps individually, e.g.:
    python step1_crop.py
    python step2_split.py
    python step3_train.py
    python step4_evaluate.py
    python step5_infer.py
"""

import os
from collections import Counter

# ═══════════════════════════════════════════════════════════
#  CONFIGURE YOUR PATHS HERE — change these to match your PC
# ═══════════════════════════════════════════════════════════

# Folder containing your raw images, one subfolder per tier
# Example: r"C:\Users\Bhavi\Desktop\drone_project\raw"
RAW_DIR = r"C:\path\to\your\raw_images"

# Where cropped 224x224 images will be saved
CROPS_DIR = r"C:\path\to\your\crops"

# Where train/val/test split will be saved
SPLIT_DIR = r"C:\path\to\your\dataset_split"

# Where trained models and results will be saved
OUTPUT_DIR = r"C:\path\to\your\output"

# Path to your YOLO weights file (best.pt)
WEIGHTS_PATH = r"C:\path\to\your\best.pt"

# Path to pretrained ResNet50 weights (resnet50_imagenet.pth)
RESNET_WEIGHTS = r"C:\path\to\your\resnet50_imagenet.pth"

# Path to pretrained EfficientNetB0 weights (efficientnetb0_imagenet.pth)
EFFICIENT_WEIGHTS = r"C:\path\to\your\efficientnetb0_imagenet.pth"

# ═══════════════════════════════════════════════════════════
#  STEP 3 (TRAIN) SETTINGS
# ═══════════════════════════════════════════════════════════

# Which model to train: "both" / "resnet50" / "efficientnetb0"
TRAIN_MODEL = "both"

# Training epochs (reduce for a quick test run)
P1_EPOCHS = 15   # Phase 1 — frozen backbone
P2_EPOCHS = 20   # Phase 2 — fine-tuning

BATCH_TRAIN  = 16
BATCH_VAL    = 32
NUM_WORKERS  = 0
WEIGHT_DECAY = 1e-4
P1_LR        = 1e-3
P2_LR        = 1e-5

# ═══════════════════════════════════════════════════════════
#  STEP 5 CONFIG — 2-Stage Inference (fill when ready)
# ═══════════════════════════════════════════════════════════

# Path to your trained Stage 2 classifier (best_model.pth from Step 3/4)
# Use whichever model won in Step 4 comparison
# Example: r"C:\drone_project\output\efficientnetb0\best_model.pth"
CLASSIFIER_PATH = r"C:\path\to\output\efficientnetb0\best_model.pth"

# Which classifier architecture matches the weights above
# "efficientnetb0" or "resnet50"
CLASSIFIER_TYPE = "efficientnetb0"

# Input source for inference:
# - Path to a video file:  r"C:\videos\test.mp4"
# - Path to image folder:  r"C:\images\test_images"
# - Single image:          r"C:\images\test.jpg"
# - Webcam:                0
INFER_SOURCE = r"C:\path\to\your\video_or_images"

# Where to save annotated output frames/video
INFER_OUTPUT_DIR = r"C:\path\to\your\inference_output"

# Minimum bbox pixel area to attempt size classification
# Boxes smaller than this → labelled "drone (size N/A)"
# Tune based on your camera resolution
# 40x40 px = 1600 is a good starting point
BBOX_AREA_THRESHOLD = 1600

# Temporal smoothing — majority vote over N frames per tracked object
# Higher = more stable label, slower to update (20 recommended)
SMOOTH_FRAMES = 20

# Show output window during inference (set False for headless/server)
SHOW_WINDOW = True

# Save annotated frames to INFER_OUTPUT_DIR
SAVE_INFER_OUTPUT = True

# ═══════════════════════════════════════════════════════════
#  DO NOT EDIT BELOW THIS LINE — shared constants / helpers
# ═══════════════════════════════════════════════════════════

TIERS          = ["nano", "micro", "small", "medium", "large"]
IMAGE_SIZE     = 224
NUM_CLASSES    = 5
IMAGENET_MEAN  = [0.485, 0.456, 0.406]
IMAGENET_STD   = [0.229, 0.224, 0.225]
SUPPORTED_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def separator(title):
    print(f"\n{'═'*55}")
    print(f"  {title}")
    print(f"{'═'*55}")


def check_placeholders(paths):
    """Exit with a clear error if any path in `paths` still has a placeholder value."""
    import sys
    placeholder_paths = [p for p in paths if "path\\to\\your" in p or "path/to/your" in p]
    if placeholder_paths:
        print("\n" + "!"*55)
        print("  ERROR: Please fill in your actual paths in config.py.")
        print("  These still have placeholder values:")
        for p in placeholder_paths:
            print(f"    {p}")
        print("!"*55 + "\n")
        sys.exit(1)
