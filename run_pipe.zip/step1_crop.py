"""
STEP 1 — Crop Raw Images Using YOLO
===================================================
Run:
    python step1_crop.py
"""

import os
import sys
from pathlib import Path
from collections import Counter

from config import (
    RAW_DIR, CROPS_DIR, WEIGHTS_PATH,
    IMAGE_SIZE, SUPPORTED_EXTS, TIERS,
    separator, check_placeholders,
)

CONF_THRESH       = 0.35
MAX_BOX_AREA_FRAC = 0.15
MIN_BOX_AREA_PX   = 20 * 20
MAX_ASPECT_RATIO  = 4.0
MARGIN_FRAC       = 0.15


def is_valid_box(x1, y1, x2, y2, fw, fh):
    w, h = x2-x1, y2-y1
    area = w * h
    if area > MAX_BOX_AREA_FRAC * fw * fh: return False, "too_large"
    if area < MIN_BOX_AREA_PX:             return False, "too_small"
    if w <= 0 or h <= 0:                   return False, "degenerate"
    if max(w/h, h/w) > MAX_ASPECT_RATIO:   return False, "bad_aspect"
    if h > 0.5*fh and w < 0.4*h:          return False, "person_shape"
    return True, "ok"


def crop_and_resize(img, x1, y1, x2, y2):
    import cv2
    ih, iw = img.shape[:2]
    bw, bh = x2-x1, y2-y1
    cx1 = max(0, int(x1 - bw*MARGIN_FRAC))
    cy1 = max(0, int(y1 - bh*MARGIN_FRAC))
    cx2 = min(iw, int(x2 + bw*MARGIN_FRAC))
    cy2 = min(ih, int(y2 + bh*MARGIN_FRAC))
    crop = img[cy1:cy2, cx1:cx2]
    if crop.size == 0: return None
    return cv2.resize(crop, (IMAGE_SIZE, IMAGE_SIZE), interpolation=cv2.INTER_AREA)


def build_contact_sheet(out_dir, tier):
    import cv2
    import numpy as np
    files = sorted([f for f in Path(out_dir).glob("*.jpg") if not f.name.startswith("_")])
    if not files: return
    imgs = [cv2.resize(cv2.imread(str(f)), (128,128)) for f in files if cv2.imread(str(f)) is not None]
    cols, cell = 8, 130
    rows = (len(imgs)+cols-1)//cols
    grid = np.ones((rows*cell, cols*cell, 3), dtype="uint8") * 240
    for i, im in enumerate(imgs):
        r, c = i//cols, i%cols
        grid[r*cell+1:r*cell+129, c*cell+1:c*cell+129] = im
    path = os.path.join(out_dir, f"_contact_sheet_{tier}.jpg")
    cv2.imwrite(path, grid)
    print(f"  Contact sheet → {path}")
    print(f"  ⚠ OPEN THIS FILE and delete any bad crops before running Step 2!")


def run_step1():
    separator("STEP 1 — Crop Raw Images Using YOLO")
    try:
        from ultralytics import YOLO
        import cv2
    except ImportError:
        print("ERROR: ultralytics or opencv not installed.")
        print("       Run: pip install ultralytics opencv-python")
        sys.exit(1)

    if not os.path.exists(WEIGHTS_PATH):
        print(f"ERROR: YOLO weights not found: {WEIGHTS_PATH}")
        sys.exit(1)

    print(f"Loading YOLO model from {WEIGHTS_PATH} ...")
    model = YOLO(WEIGHTS_PATH)
    print(f"Classes: {model.names}\n")

    for tier in TIERS:
        in_dir  = os.path.join(RAW_DIR,   tier)
        out_dir = os.path.join(CROPS_DIR, tier)

        if not os.path.exists(in_dir):
            print(f"  [{tier}] SKIP — folder not found: {in_dir}")
            continue

        os.makedirs(out_dir, exist_ok=True)
        files = sorted([f for f in Path(in_dir).iterdir() if f.suffix.lower() in SUPPORTED_EXTS])
        print(f"\n  [{tier}] {len(files)} images found")

        counts = Counter()
        for idx, fpath in enumerate(files):
            img = cv2.imread(str(fpath))
            if img is None:
                counts["read_error"] += 1; continue

            fh, fw = img.shape[:2]
            results = model.predict(str(fpath), conf=CONF_THRESH, verbose=False)
            r = results[0]

            if r.boxes is None or len(r.boxes) == 0:
                counts["no_detection"] += 1; continue

            confs = r.boxes.conf.tolist()
            boxes = r.boxes.xyxy.tolist()
            best  = max(range(len(confs)), key=lambda i: confs[i])
            x1,y1,x2,y2 = boxes[best]
            conf = confs[best]

            ok, reason = is_valid_box(x1,y1,x2,y2,fw,fh)
            if not ok:
                counts[f"rejected_{reason}"] += 1; continue

            crop = crop_and_resize(img, x1,y1,x2,y2)
            if crop is None:
                counts["empty_crop"] += 1; continue

            out_name = f"{tier}_{fpath.stem}.jpg"
            cv2.imwrite(os.path.join(out_dir, out_name), crop)
            counts["kept"] += 1

            if (idx+1) % 50 == 0:
                print(f"    {idx+1}/{len(files)} processed ... kept={counts['kept']}")

        print(f"\n  [{tier}] Results:")
        for status, count in counts.most_common():
            print(f"    {status:30s}: {count}")

        build_contact_sheet(out_dir, tier)

        if counts["kept"] < 300:
            print(f"  ⚠ WARNING: Only {counts['kept']} crops — consider adding more images for [{tier}]")
        else:
            print(f"  ✓ {counts['kept']} crops saved to {out_dir}")

    print("\n  ✓ Step 1 complete")


if __name__ == "__main__":
    check_placeholders([RAW_DIR, WEIGHTS_PATH])
    os.makedirs(CROPS_DIR, exist_ok=True)
    run_step1()
