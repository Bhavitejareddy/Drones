"""
STEP 2 — Split into Train / Val / Test
===================================================
Run:
    python step2_split.py
"""

import os
import random
import shutil
from pathlib import Path

from config import (
    CROPS_DIR, SPLIT_DIR,
    SUPPORTED_EXTS, TIERS,
    separator, check_placeholders,
)

TRAIN_FRAC = 0.70
VAL_FRAC   = 0.15
SEED       = 42


def run_step2():
    separator("STEP 2 — Split into Train / Val / Test")
    random.seed(SEED)
    print(f"  Split: {TRAIN_FRAC:.0%} train / {VAL_FRAC:.0%} val / {1-TRAIN_FRAC-VAL_FRAC:.0%} test\n")

    for tier in TIERS:
        src = Path(CROPS_DIR) / tier
        if not src.exists():
            print(f"  [{tier}] SKIP — {src} not found"); continue

        files = sorted([
            f for f in src.iterdir()
            if f.suffix.lower() in SUPPORTED_EXTS and not f.name.startswith("_")
        ])
        if not files:
            print(f"  [{tier}] SKIP — no images"); continue

        random.shuffle(files)
        n       = len(files)
        n_train = int(n * TRAIN_FRAC)
        n_val   = int(n * VAL_FRAC)

        splits = {
            "train": files[:n_train],
            "val":   files[n_train:n_train+n_val],
            "test":  files[n_train+n_val:],
        }
        for split_name, split_files in splits.items():
            dest = Path(SPLIT_DIR) / split_name / tier
            dest.mkdir(parents=True, exist_ok=True)
            for f in split_files:
                shutil.copy2(f, dest/f.name)

        print(
            f"  {tier:8s}  total={n:4d}  "
            f"train={len(splits['train']):4d}  "
            f"val={len(splits['val']):4d}  "
            f"test={len(splits['test']):4d}"
        )
    print("\n  ✓ Split complete")


if __name__ == "__main__":
    check_placeholders([CROPS_DIR])
    os.makedirs(SPLIT_DIR, exist_ok=True)
    run_step2()
