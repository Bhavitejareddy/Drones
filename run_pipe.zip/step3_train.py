"""
STEP 3 — Train Classifier (ResNet50 + EfficientNetB0)
===================================================
Run:
    python step3_train.py
"""

import os
import csv
import copy
import time

from config import (
    SPLIT_DIR, OUTPUT_DIR, RESNET_WEIGHTS, EFFICIENT_WEIGHTS,
    IMAGE_SIZE, NUM_CLASSES, IMAGENET_MEAN, IMAGENET_STD,
    TRAIN_MODEL, P1_EPOCHS, P2_EPOCHS,
    BATCH_TRAIN, BATCH_VAL, NUM_WORKERS, WEIGHT_DECAY, P1_LR, P2_LR,
    separator, check_placeholders,
)


def get_transforms():
    from torchvision import transforms
    train_tf = transforms.Compose([
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
        transforms.RandomHorizontalFlip(0.5),
        transforms.RandomRotation(15),
        transforms.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.2),
        transforms.RandomAffine(0, translate=(0.1,0.1), scale=(0.85,1.15)),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])
    val_tf = transforms.Compose([
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])
    return train_tf, val_tf


def load_data(train_tf, val_tf):
    from torchvision import datasets
    from torch.utils.data import DataLoader
    train_ds = datasets.ImageFolder(os.path.join(SPLIT_DIR,"train"), transform=train_tf)
    val_ds   = datasets.ImageFolder(os.path.join(SPLIT_DIR,"val"),   transform=val_tf)
    tr = DataLoader(train_ds, batch_size=BATCH_TRAIN, shuffle=True,  num_workers=NUM_WORKERS)
    vl = DataLoader(val_ds,   batch_size=BATCH_VAL,   shuffle=False, num_workers=NUM_WORKERS)
    print(f"  Classes : {train_ds.classes}")
    print(f"  Train   : {len(train_ds)} images")
    print(f"  Val     : {len(val_ds)} images\n")
    return tr, vl, train_ds.classes


def build_resnet50():
    import torch
    from torchvision import models
    import torch.nn as nn
    m = models.resnet50(weights=None)
    if os.path.exists(RESNET_WEIGHTS):
        m.load_state_dict(torch.load(RESNET_WEIGHTS, map_location="cpu"))
        print(f"  ResNet50: loaded {RESNET_WEIGHTS}")
    else:
        print(f"  ResNet50: no pretrained weights found — training from scratch")
    m.fc = nn.Sequential(nn.Dropout(0.3), nn.Linear(m.fc.in_features, NUM_CLASSES))
    return m


def build_efficientnetb0():
    import torch
    from torchvision import models
    import torch.nn as nn
    m = models.efficientnet_b0(weights=None)
    if os.path.exists(EFFICIENT_WEIGHTS):
        m.load_state_dict(torch.load(EFFICIENT_WEIGHTS, map_location="cpu"))
        print(f"  EfficientNetB0: loaded {EFFICIENT_WEIGHTS}")
    else:
        print(f"  EfficientNetB0: no pretrained weights found — training from scratch")
    in_feat = m.classifier[1].in_features
    m.classifier = nn.Sequential(nn.Dropout(0.3), nn.Linear(in_feat, NUM_CLASSES))
    return m


def run_epoch(model, loader, criterion, optimizer, is_train):
    import torch
    model.train() if is_train else model.eval()
    loss_sum = correct = total = 0
    with torch.set_grad_enabled(is_train):
        for imgs, labels in loader:
            out  = model(imgs)
            loss = criterion(out, labels)
            if is_train:
                optimizer.zero_grad(); loss.backward(); optimizer.step()
            loss_sum += loss.item() * imgs.size(0)
            correct  += (out.argmax(1)==labels).sum().item()
            total    += imgs.size(0)
    return loss_sum/total, correct/total


def train_phase(model, tr, vl, crit, opt, sch, epochs, phase, mname, log, out_dir):
    import torch
    best_acc, best_wt = 0.0, copy.deepcopy(model.state_dict())
    best_path = os.path.join(out_dir, mname, "best_model.pth")
    print(f"\n  [{mname}] {phase} — {epochs} epochs")
    print(f"  {'─'*48}")
    for ep in range(1, epochs+1):
        t0 = time.time()
        tl, ta = run_epoch(model, tr, crit, opt, True)
        vl_, va = run_epoch(model, vl, crit, None, False)
        sch.step(vl_)
        mark = ""
        if va > best_acc:
            best_acc = va
            best_wt  = copy.deepcopy(model.state_dict())
            torch.save(best_wt, best_path)
            mark = "  ← best"
        print(f"  Ep {ep:2d}/{epochs}  loss={tl:.3f} acc={ta:.3f}  |  val_loss={vl_:.3f} val_acc={va:.3f}  ({time.time()-t0:.0f}s){mark}")
        log.append([phase, ep, round(tl,4), round(ta,4), round(vl_,4), round(va,4)])
    print(f"  [{mname}] Best val acc: {best_acc:.4f}")
    return best_wt, best_acc


def train_one_model(mname, model, freeze_fn, unfreeze_fn, tr, vl, out_dir):
    import torch
    import torch.nn as nn
    import torch.optim as optim
    os.makedirs(os.path.join(out_dir, mname), exist_ok=True)
    log  = []
    crit = nn.CrossEntropyLoss()

    freeze_fn(model)
    opt1 = optim.Adam(filter(lambda p:p.requires_grad, model.parameters()), lr=P1_LR, weight_decay=WEIGHT_DECAY)
    sch1 = optim.lr_scheduler.ReduceLROnPlateau(opt1, patience=3, factor=0.5)
    bwt, acc1 = train_phase(model, tr, vl, crit, opt1, sch1, P1_EPOCHS, "Phase1", mname, log, out_dir)

    model.load_state_dict(bwt)
    unfreeze_fn(model)
    opt2 = optim.Adam(filter(lambda p:p.requires_grad, model.parameters()), lr=P2_LR, weight_decay=WEIGHT_DECAY)
    sch2 = optim.lr_scheduler.ReduceLROnPlateau(opt2, patience=4, factor=0.5)
    bwt2, acc2 = train_phase(model, tr, vl, crit, opt2, sch2, P2_EPOCHS, "Phase2", mname, log, out_dir)

    model.load_state_dict(bwt2)
    torch.save(model.state_dict(), os.path.join(out_dir, mname, "final_model.pth"))

    with open(os.path.join(out_dir, mname, "training_log.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["phase","epoch","train_loss","train_acc","val_loss","val_acc"])
        w.writerows(log)

    try:
        import matplotlib; matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        p1 = [r for r in log if r[0]=="Phase1"]
        p2 = [r for r in log if r[0]=="Phase2"]
        fig,(a1,a2) = plt.subplots(1,2,figsize=(12,4))
        for rows,lbl,col in [(p1,"Phase1","steelblue"),(p2,"Phase2","coral")]:
            if not rows: continue
            ep=[r[1] for r in rows]
            a1.plot(ep,[r[2] for r in rows],"--",color=col,alpha=0.6)
            a1.plot(ep,[r[4] for r in rows],"-", color=col,label=lbl)
            a2.plot(ep,[r[3] for r in rows],"--",color=col,alpha=0.6)
            a2.plot(ep,[r[5] for r in rows],"-", color=col,label=lbl)
        a1.set_title("Loss");a1.legend();a2.set_title("Accuracy");a2.legend()
        plt.suptitle(f"{mname} — Training"); plt.tight_layout()
        plt.savefig(os.path.join(out_dir,mname,"training_curves.png"),dpi=150); plt.close()
    except: pass

    return max(acc1, acc2)


def freeze_resnet(m):
    for n,p in m.named_parameters(): p.requires_grad=("fc" in n)


def unfreeze_resnet(m):
    for n,p in m.named_parameters():
        if any(g in n for g in ["layer4","layer3","fc"]): p.requires_grad=True


def freeze_efficient(m):
    for n,p in m.named_parameters(): p.requires_grad=("classifier" in n)


def unfreeze_efficient(m):
    for n,p in m.named_parameters():
        if "classifier" in n: p.requires_grad=True
        elif "features" in n:
            try:
                if int(n.split(".")[1]) >= 6: p.requires_grad=True
            except: pass


def run_step3():
    separator("STEP 3 — Train Classifier")
    import torch
    print(f"  PyTorch : {torch.__version__}  |  Device: CPU")
    print(f"  Model   : {TRAIN_MODEL}\n")

    train_tf, val_tf  = get_transforms()
    tr, vl, classes   = load_data(train_tf, val_tf)
    results = {}

    with open(os.path.join(OUTPUT_DIR,"class_names.txt"),"w") as f:
        [f.write(f"{i} {c}\n") for i,c in enumerate(classes)]

    if TRAIN_MODEL in ("both","resnet50"):
        print("\n  ── Training ResNet50 ──")
        m = build_resnet50()
        results["resnet50"] = train_one_model("resnet50", m, freeze_resnet, unfreeze_resnet, tr, vl, OUTPUT_DIR)

    if TRAIN_MODEL in ("both","efficientnetb0"):
        print("\n  ── Training EfficientNetB0 ──")
        m = build_efficientnetb0()
        results["efficientnetb0"] = train_one_model("efficientnetb0", m, freeze_efficient, unfreeze_efficient, tr, vl, OUTPUT_DIR)

    print(f"\n  Val Accuracy Summary:")
    winner = max(results, key=results.get)
    for name, acc in results.items():
        mark = "  ← winner" if name==winner else ""
        print(f"  {name:20s}  {acc*100:.1f}%{mark}")
    print(f"\n  ✓ Training complete. Run Step 4 to evaluate on test set.")


if __name__ == "__main__":
    check_placeholders([SPLIT_DIR])
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    run_step3()
