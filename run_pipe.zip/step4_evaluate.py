"""
STEP 4 — Evaluate & Compare Trained Models
===================================================
Run:
    python step4_evaluate.py
"""

import os

from config import (
    SPLIT_DIR, OUTPUT_DIR,
    IMAGE_SIZE, NUM_CLASSES, IMAGENET_MEAN, IMAGENET_STD,
    BATCH_VAL, NUM_WORKERS, TIERS,
    separator, check_placeholders,
)


def evaluate_model(mname, model_path, classes):
    import torch
    import torch.nn as nn
    from torchvision import datasets, transforms, models
    from torch.utils.data import DataLoader

    # Load model
    if "resnet" in mname:
        m = models.resnet50(weights=None)
        m.fc = nn.Sequential(nn.Dropout(0.3), nn.Linear(m.fc.in_features, NUM_CLASSES))
    else:
        m = models.efficientnet_b0(weights=None)
        in_feat = m.classifier[1].in_features
        m.classifier = nn.Sequential(nn.Dropout(0.3), nn.Linear(in_feat, NUM_CLASSES))

    m.load_state_dict(torch.load(model_path, map_location="cpu"))
    m.eval()

    tf = transforms.Compose([
        transforms.Resize((IMAGE_SIZE,IMAGE_SIZE)),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])
    ds     = datasets.ImageFolder(os.path.join(SPLIT_DIR,"test"), transform=tf)
    loader = DataLoader(ds, batch_size=BATCH_VAL, shuffle=False, num_workers=NUM_WORKERS)

    preds, labels = [], []
    with torch.no_grad():
        for imgs, lbls in loader:
            preds.extend(m(imgs).argmax(1).tolist())
            labels.extend(lbls.tolist())

    # Metrics
    n  = len(classes)
    cm = [[0]*n for _ in range(n)]
    pc = [0]*n; pt = [0]*n
    for p,l in zip(preds,labels):
        cm[l][p]+=1; pt[l]+=1
        if p==l: pc[l]+=1
    overall  = sum(pc)/len(labels)
    per_acc  = [pc[i]/pt[i] if pt[i]>0 else 0.0 for i in range(n)]

    # Print report
    lines = [f"\n  [{mname}]  Overall accuracy: {overall*100:.1f}%\n"]
    lines.append(f"  {'Tier':10s}  {'N':>5s}  {'Acc':>7s}  Bar")
    lines.append(f"  {'─'*45}")
    for i,cls in enumerate(classes):
        bar = "█"*int(per_acc[i]*20) + "░"*(20-int(per_acc[i]*20))
        lines.append(f"  {cls:10s}  {pt[i]:5d}  {per_acc[i]*100:6.1f}%  {bar}")
    lines.append(f"\n  Confusion matrix (rows=actual, cols=predicted):")
    lines.append(f"  {'':12s}" + "".join(f"{c:>9s}" for c in classes))
    for i,rc in enumerate(classes):
        lines.append(f"  {rc:12s}" + "".join(f"{cm[i][j]:9d}" for j in range(n)))
    report = "\n".join(lines)
    print(report)

    os.makedirs(os.path.join(OUTPUT_DIR,mname), exist_ok=True)
    with open(os.path.join(OUTPUT_DIR,mname,"evaluation_report.txt"),"w") as f:
        f.write(report)

    # Plot
    try:
        import matplotlib; matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import numpy as np
        arr  = np.array(cm,dtype=float)
        norm = arr / arr.sum(axis=1,keepdims=True).clip(min=1)
        fig,ax = plt.subplots(figsize=(7,6))
        im = ax.imshow(norm,cmap="Blues",vmin=0,vmax=1)
        plt.colorbar(im,ax=ax,fraction=0.046,pad=0.04)
        ax.set_xticks(range(n)); ax.set_xticklabels(classes,rotation=45,ha="right")
        ax.set_yticks(range(n)); ax.set_yticklabels(classes)
        ax.set_xlabel("Predicted"); ax.set_ylabel("Actual")
        ax.set_title(f"{mname} — Confusion Matrix")
        for i in range(n):
            for j in range(n):
                ax.text(j,i,str(int(arr[i,j])),ha="center",va="center",
                        color="white" if norm[i,j]>0.6 else "black",fontsize=10)
        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_DIR,mname,"confusion_matrix.png"),dpi=150)
        plt.close()
    except: pass

    return overall, per_acc


def run_step4():
    separator("STEP 4 — Evaluate & Compare")
    results = {}

    # Load class names
    class_file = os.path.join(OUTPUT_DIR,"class_names.txt")
    if os.path.exists(class_file):
        with open(class_file) as f:
            classes = [line.strip().split()[1] for line in f if line.strip()]
    else:
        classes = TIERS

    for mname in ["resnet50","efficientnetb0"]:
        mpath = os.path.join(OUTPUT_DIR, mname, "best_model.pth")
        if not os.path.exists(mpath):
            print(f"  [{mname}] SKIP — {mpath} not found"); continue
        print(f"\n  Evaluating {mname} ...")
        overall, per_acc = evaluate_model(mname, mpath, classes)
        results[mname] = {"overall": overall, "per_acc": per_acc}

    if len(results) > 1:
        winner = max(results, key=lambda x: results[x]["overall"])
        lines  = [f"\n{'═'*55}", f"  FINAL COMPARISON", f"{'═'*55}\n"]
        for name, res in results.items():
            acc  = res["overall"]
            bar  = "█"*int(acc*30)
            mark = "  ← USE THIS MODEL" if name==winner else ""
            lines.append(f"  {name:20s}  {acc*100:5.1f}%  {bar}{mark}")
        lines.append(f"\n  Best model path:")
        lines.append(f"  {os.path.join(OUTPUT_DIR, winner, 'best_model.pth')}")
        report = "\n".join(lines)
        print(report)
        with open(os.path.join(OUTPUT_DIR,"comparison_report.txt"),"w") as f:
            f.write(report)
        print(f"\n  ✓ Comparison report → {os.path.join(OUTPUT_DIR,'comparison_report.txt')}")


if __name__ == "__main__":
    check_placeholders([SPLIT_DIR, OUTPUT_DIR])
    run_step4()
