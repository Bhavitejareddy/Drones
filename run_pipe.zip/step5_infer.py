"""
STEP 5 — Full 2-Stage Inference Pipeline
===================================================
Matches your diagram exactly:

 Image/Video
     │
 Stage 1: YOLOv12n → drone / bird / aircraft / helicopter
     │
 class == drone?
 ├── No  → final label = bird / aircraft / helicopter
 └── Yes → bbox area >= threshold?
           ├── No  → "drone (size N/A)"
           └── Yes → Stage 2 classifier → nano/micro/small/medium/large

Run (only after Steps 1-4 are complete and CLASSIFIER_PATH is set in config.py):
    python step5_infer.py
"""

import os
import sys
from pathlib import Path
from collections import Counter

from config import (
    WEIGHTS_PATH, CLASSIFIER_PATH, CLASSIFIER_TYPE,
    INFER_SOURCE, INFER_OUTPUT_DIR,
    BBOX_AREA_THRESHOLD, SMOOTH_FRAMES, SHOW_WINDOW, SAVE_INFER_OUTPUT,
    OUTPUT_DIR, IMAGE_SIZE, NUM_CLASSES, IMAGENET_MEAN, IMAGENET_STD,
    SUPPORTED_EXTS, TIERS,
    separator,
)


def load_stage2_classifier():
    """Load the trained size classifier (ResNet50 or EfficientNetB0)."""
    import torch
    import torch.nn as nn
    from torchvision import models

    if not os.path.exists(CLASSIFIER_PATH):
        print(f"ERROR: Classifier not found: {CLASSIFIER_PATH}")
        print(f"       Run Steps 1-4 first to train the classifier.")
        sys.exit(1)

    if CLASSIFIER_TYPE == "efficientnetb0":
        m = models.efficientnet_b0(weights=None)
        in_feat = m.classifier[1].in_features
        m.classifier = nn.Sequential(nn.Dropout(0.3), nn.Linear(in_feat, NUM_CLASSES))
    else:
        m = models.resnet50(weights=None)
        m.fc = nn.Sequential(nn.Dropout(0.3), nn.Linear(m.fc.in_features, NUM_CLASSES))

    m.load_state_dict(torch.load(CLASSIFIER_PATH, map_location="cpu"))
    m.eval()
    print(f"  Stage 2 classifier loaded: {CLASSIFIER_TYPE}")
    return m


def get_infer_transform():
    from torchvision import transforms
    return transforms.Compose([
        transforms.ToPILImage(),
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
        transforms.ToTensor(),
        transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])


def classify_size(classifier, crop_bgr, tf, class_names):
    """Run Stage 2 on a cropped drone region. Returns (tier_label, confidence)."""
    import torch
    # BGR → RGB for PIL
    crop_rgb = crop_bgr[:, :, ::-1].copy()
    tensor   = tf(crop_rgb).unsqueeze(0)   # (1, 3, 224, 224)
    with torch.no_grad():
        out   = classifier(tensor)
        probs = torch.softmax(out, dim=1)[0]
        idx   = probs.argmax().item()
    return class_names[idx], float(probs[idx])


# ── IoU helper ───────────────────────────────────────────────
def iou(a, b):
    ax1,ay1,ax2,ay2 = a
    bx1,by1,bx2,by2 = b
    ix1,iy1 = max(ax1,bx1), max(ay1,by1)
    ix2,iy2 = min(ax2,bx2), min(ay2,by2)
    inter   = max(0,ix2-ix1)*max(0,iy2-iy1)
    if inter == 0: return 0.0
    return inter / ((ax2-ax1)*(ay2-ay1) + (bx2-bx1)*(by2-by1) - inter)


# ── Simple per-object label smoother ────────────────────────
class LabelSmoother:
    """Keeps rolling label history per tracked object. Returns majority vote."""
    def __init__(self, window=20):
        from collections import deque
        self.window   = window
        self.history  = deque(maxlen=window)

    def update(self, label):
        self.history.append(label)

    @property
    def stable(self):
        if not self.history: return None
        return Counter(self.history).most_common(1)[0][0]

    @property
    def count(self):
        return len(self.history)


# ── Tracker ──────────────────────────────────────────────────
class ObjectTracker:
    _next_id = 1
    IOU_THRESH  = 0.25
    MAX_MISSED  = 15
    ALPHA       = 0.35   # bbox smoothing

    def __init__(self, box, label):
        self.id      = ObjectTracker._next_id
        ObjectTracker._next_id += 1
        self.box     = list(map(float, box))
        self.smoother= LabelSmoother(SMOOTH_FRAMES)
        self.smoother.update(label)
        self.missed  = 0
        self.age     = 1

    def update(self, box, label):
        for i in range(4):
            self.box[i] = self.ALPHA*box[i] + (1-self.ALPHA)*self.box[i]
        self.smoother.update(label)
        self.missed = 0
        self.age   += 1

    def mark_missed(self):
        self.missed += 1

    @property
    def ibox(self):
        return [int(v) for v in self.box]

    @property
    def visible(self):
        return self.age >= 5 and self.missed == 0


class TrackerPool:
    def __init__(self):
        self.pool = []

    def update(self, detections):
        matched_t, matched_d = set(), set()
        for di, (box, label) in enumerate(detections):
            best_iou, best_t = ObjectTracker.IOU_THRESH, None
            for t in self.pool:
                v = iou(box, t.box)
                if v > best_iou:
                    best_iou, best_t = v, t
            if best_t:
                best_t.update(box, label)
                matched_t.add(best_t.id); matched_d.add(di)
        for di, (box, label) in enumerate(detections):
            if di not in matched_d:
                self.pool.append(ObjectTracker(box, label))
        for t in self.pool:
            if t.id not in matched_t: t.mark_missed()
        self.pool = [t for t in self.pool if t.missed < ObjectTracker.MAX_MISSED]
        return self.pool


# ── Class colors ─────────────────────────────────────────────
COLORS = {
    "drone":      (0,   0,   255),
    "bird":       (0,   255, 0  ),
    "aircraft":   (255, 0,   0  ),
    "helicopter": (0,   165, 255),
    "nano":       (0,   0,   200),
    "micro":      (0,   100, 255),
    "small":      (0,   200, 255),
    "medium":     (0,   255, 200),
    "large":      (50,  255, 50 ),
}
DEFAULT_COLOR = (200, 200, 200)


def draw_box(img, x1, y1, x2, y2, label, conf, color, extra=""):
    import cv2
    cv2.rectangle(img, (x1,y1), (x2,y2), color, 2)
    text = f"{label} {conf:.2f}{extra}"
    (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
    cv2.rectangle(img, (x1, y1-th-8), (x1+tw+6, y1), color, -1)
    cv2.putText(img, text, (x1+3, y1-4),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 2)


def _process_frame(frame, yolo, classifier, infer_tf, size_classes, tracker, frame_idx):
    """
    Core 2-stage logic per frame.
    Returns list of (x1,y1,x2,y2, final_label, conf, color)
    """
    fh, fw = frame.shape[:2]
    results = yolo.predict(frame, conf=0.4, iou=0.45, verbose=False)
    r       = results[0]

    raw_detections = []   # (box, display_label) for tracker

    for box in r.boxes:
        x1,y1,x2,y2 = map(float, box.xyxy[0])
        cls_id = int(box.cls[0])
        conf   = float(box.conf[0])
        label  = r.names[cls_id].lower()

        # ── STAGE 1 branch ──────────────────────────────────────
        if label != "drone":
            # bird / aircraft / helicopter — final label from Stage 1
            final_label = label
            final_conf  = conf
            color       = COLORS.get(label, DEFAULT_COLOR)

        else:
            # ── Drone detected — check bbox area gate ───────────
            bbox_area = (x2-x1) * (y2-y1)

            if bbox_area < BBOX_AREA_THRESHOLD:
                # Too small to classify size reliably
                final_label = "drone (size N/A)"
                final_conf  = conf
                color       = COLORS["drone"]

            else:
                # ── STAGE 2: crop → size classifier ─────────────
                cx1 = max(0, int(x1)); cy1 = max(0, int(y1))
                cx2 = min(fw, int(x2)); cy2 = min(fh, int(y2))
                crop = frame[cy1:cy2, cx1:cx2]

                if crop.size == 0:
                    final_label = "drone (size N/A)"
                    final_conf  = conf
                    color       = COLORS["drone"]
                else:
                    size_tier, size_conf = classify_size(
                        classifier, crop, infer_tf, size_classes)
                    final_label = f"drone ({size_tier})"
                    final_conf  = size_conf
                    color       = COLORS.get(size_tier, COLORS["drone"])

        raw_detections.append(([x1,y1,x2,y2], final_label))

    # ── Update tracker (temporal smoothing) ─────────────────────
    active = tracker.update(raw_detections)

    # Build final draw list from stable trackers
    draw_list = []
    for t in active:
        if t.visible:
            draw_list.append((
                t.ibox,
                t.smoother.stable,
                0.0,   # conf shown on label comes from raw detection
                COLORS.get(
                    t.smoother.stable.replace("drone (","").replace(")",""),
                    COLORS.get("drone", DEFAULT_COLOR)
                )
            ))
    return draw_list


def _draw_frame(frame, draw_list, frame_idx):
    import cv2
    hud_counts = Counter()
    for (box, label, conf, color) in draw_list:
        x1,y1,x2,y2 = box
        draw_box(frame, x1,y1,x2,y2, label, conf, color)
        hud_counts[label] += 1

    # HUD
    hud_y = 28
    for lbl, cnt in hud_counts.items():
        base = lbl.replace("drone (","").replace(")","")
        color = COLORS.get(base, DEFAULT_COLOR)
        cv2.putText(frame, f"{lbl}: {cnt}", (10, hud_y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        hud_y += 30

    cv2.putText(frame, f"Frame {frame_idx}  |  window={SMOOTH_FRAMES}fr  |  area_thresh={BBOX_AREA_THRESHOLD}px",
                (10, frame.shape[0]-10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (180,180,180), 1)


def _run_step5_images(image_files, yolo, classifier, infer_tf, size_classes):
    """Process a folder of images (no video loop needed)."""
    import cv2
    tracker = TrackerPool()
    for idx, fpath in enumerate(image_files):
        frame = cv2.imread(fpath)
        if frame is None: continue
        draw_list = _process_frame(frame, yolo, classifier, infer_tf,
                                   size_classes, tracker, idx)
        _draw_frame(frame, draw_list, idx)
        if SAVE_INFER_OUTPUT:
            out = os.path.join(INFER_OUTPUT_DIR, Path(fpath).name)
            cv2.imwrite(out, frame)
        if SHOW_WINDOW:
            cv2.imshow("2-Stage Drone Pipeline", frame)
            key = cv2.waitKey(0) & 0xFF
            if key == ord('q'): break
        if (idx+1) % 20 == 0:
            print(f"  {idx+1}/{len(image_files)} images done")
    if SHOW_WINDOW:
        cv2.destroyAllWindows()
    print(f"  ✓ Done. {len(image_files)} images processed.")
    if SAVE_INFER_OUTPUT:
        print(f"  Output saved to: {INFER_OUTPUT_DIR}")


def run_step5():
    separator("STEP 5 — 2-Stage Inference Pipeline")
    import cv2
    import torch
    from ultralytics import YOLO

    # ── Validate paths
    for label, path in [("WEIGHTS_PATH", WEIGHTS_PATH),
                         ("CLASSIFIER_PATH", CLASSIFIER_PATH)]:
        if "path\\to" in path or "path/to" in path:
            print(f"ERROR: {label} still has placeholder value. Fill it in config.py.")
            sys.exit(1)

    if SAVE_INFER_OUTPUT:
        os.makedirs(INFER_OUTPUT_DIR, exist_ok=True)

    # ── Load class names for Stage 2
    class_file = os.path.join(OUTPUT_DIR, "class_names.txt")
    if os.path.exists(class_file):
        with open(class_file) as f:
            size_classes = [line.strip().split()[1] for line in f if line.strip()]
    else:
        size_classes = TIERS
    print(f"  Size classes : {size_classes}")

    # ── Load models
    print(f"  Loading Stage 1 YOLO from  : {WEIGHTS_PATH}")
    yolo       = YOLO(WEIGHTS_PATH)
    classifier = load_stage2_classifier()
    infer_tf   = get_infer_transform()

    # ── Open source
    if INFER_SOURCE == 0 or str(INFER_SOURCE).isdigit():
        cap = cv2.VideoCapture(0)
        print("  Source: webcam")
    elif os.path.isfile(str(INFER_SOURCE)):
        cap = cv2.VideoCapture(str(INFER_SOURCE))
        print(f"  Source: video file — {INFER_SOURCE}")
    elif os.path.isdir(str(INFER_SOURCE)):
        # Image folder mode — process each image
        image_files = sorted([
            str(f) for f in Path(INFER_SOURCE).iterdir()
            if f.suffix.lower() in SUPPORTED_EXTS
        ])
        print(f"  Source: image folder — {len(image_files)} images")
        _run_step5_images(image_files, yolo, classifier, infer_tf, size_classes)
        return
    else:
        print(f"ERROR: INFER_SOURCE not found: {INFER_SOURCE}"); sys.exit(1)

    # ── Video / webcam loop
    tracker    = TrackerPool()
    frame_idx  = 0
    paused     = False
    print("\n  Controls: Q=quit  S=save frame  SPACE=pause\n")

    while cap.isOpened():
        if not paused:
            ret, frame = cap.read()
            if not ret: break

            detections = _process_frame(frame, yolo, classifier, infer_tf,
                                        size_classes, tracker, frame_idx)
            _draw_frame(frame, detections, frame_idx)

            if SAVE_INFER_OUTPUT:
                cv2.imwrite(f"{INFER_OUTPUT_DIR}/frame_{frame_idx:05d}.jpg", frame)

            frame_idx += 1

        if SHOW_WINDOW:
            cv2.imshow("2-Stage Drone Pipeline", frame)
            key = cv2.waitKey(1 if not paused else 0) & 0xFF
            if   key == ord('q'): break
            elif key == ord('s'):
                sp = f"{INFER_OUTPUT_DIR}/saved_{frame_idx:05d}.jpg"
                cv2.imwrite(sp, frame); print(f"  Saved: {sp}")
            elif key == ord(' '):
                paused = not paused
                print("Paused" if paused else "Resumed")
        else:
            if frame_idx % 100 == 0:
                print(f"  Processed {frame_idx} frames...")

    cap.release()
    if SHOW_WINDOW: cv2.destroyAllWindows()
    print(f"\n  ✓ Done. {frame_idx} frames processed.")
    if SAVE_INFER_OUTPUT:
        print(f"  Output saved to: {INFER_OUTPUT_DIR}")


if __name__ == "__main__":
    run_step5()
